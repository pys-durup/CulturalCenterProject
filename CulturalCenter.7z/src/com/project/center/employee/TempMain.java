package com.project.center.employee;

public class TempMain {

	public static void main(String[] args) {
		
		EmployeeManage m = new EmployeeManage();
		
		m.checkEmployeeManage();
		m.viewEmployeeManage();
		
	}
	
}
