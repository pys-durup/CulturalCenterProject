package com.project.center.user;

public class UserDelete {

}
